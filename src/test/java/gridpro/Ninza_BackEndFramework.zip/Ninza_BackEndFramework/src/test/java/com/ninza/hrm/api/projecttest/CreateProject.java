package com.ninza.hrm.api.projecttest;

import java.awt.AWTException;
import java.awt.RenderingHints.Key;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.channels.SelectableChannel;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.mysql.cj.jdbc.Driver;
import com.ninza.hrm.api.baseClass.BaseAPIClass;
import com.ninza.hrm.constants.endpoints.IEndPoint;
import com.ninza.hrm.generic.webdriverUtility.WebDriverUtility;
import com.ninza.hrm.objectRepository.HomePage;
import com.ninza.hrm.objectRepository.LoginPage;
import com.ninza.hrm.objectRepository.ProjectPage;

import static io.restassured.RestAssured.*;

public class CreateProject extends BaseAPIClass {

	@Test
	public void projectTest() throws InterruptedException, AWTException, SQLException, IOException
	{
	//Create project in UI
		
		String proName="Airtel"+jutils.getRandomNum();
		String userName="user"+jutils.getRandomNum();
		 WebDriver driver = new FirefoxDriver();
			driver.get(futils.getDataFromPropertyFile("BaseURI"));
			WebDriverUtility wUtils=new WebDriverUtility();
			wUtils.waitUntilPageGetLoads(driver);
			driver.manage().window().maximize();
			
			LoginPage loginpage=new LoginPage(driver);
			loginpage.login();
			
			HomePage homepage=new HomePage(driver);
			wUtils.waitUntilElementVisible(driver, homepage.getProjectPage());
	        homepage.getProjectPage().click();
	        
	        ProjectPage ppage=new ProjectPage(driver);
	        ppage.getCreateProjectIcon().click();
	        wUtils.waitUntilElementVisible(driver, ppage.getProNametxtfield());
	        ppage.createProject(proName, userName, "Created");
       Thread.sleep(5000);
    WebElement createdProjectID= driver.findElement(By.xpath("//td[.='"+proName+"']/../td[1]"));
    wUtils.waitUntilElementVisible(driver, createdProjectID);
   String cProjectID= createdProjectID.getText();
    System.out.println("ProjectCreated "+cProjectID);
     driver.close();


     // Get Project via BackEnd[API]

    given()
    .spec(reqspecObj)
    .pathParam("projectId", cProjectID)
    .when()
    .get(IEndPoint.getPro)
    .then()
    .log().all();
	
	
	//Validate the created projectName in DB Layer
	boolean flag= dUtils.selectQuery("select * from project", 4, proName);
	Assert.assertTrue(flag, "Project in DB is not verified");
	
	}
}
