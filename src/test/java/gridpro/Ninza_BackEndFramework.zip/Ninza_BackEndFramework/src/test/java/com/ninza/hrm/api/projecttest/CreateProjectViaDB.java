package com.ninza.hrm.api.projecttest;

import java.io.IOException;
import java.time.Duration;
import java.util.Random;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ninza.hrm.api.baseClass.BaseAPIClass;
import com.ninza.hrm.constants.endpoints.IEndPoint;
import com.ninza.hrm.generic.webdriverUtility.WebDriverUtility;
import com.ninza.hrm.objectRepository.HomePage;
import com.ninza.hrm.objectRepository.LoginPage;
import com.ninza.hrm.objectRepository.ProjectPage;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class CreateProjectViaDB extends BaseAPIClass{
	
	/*
	 * Create project using db
	 * Update project using API
	 * Delete using UI
	 */
	@Test
	public void createUpdateDelete() throws IOException, InterruptedException
	{
		//Create project using db
		
		String proId="NH_PROJ_"+jutils.getRandomNum();
		String projectName="user"+jutils.getRandomNum();;
		dUtils.executeNonSelectQuery("insert into project(project_id,created_by,created_on,project_name,status,team_size)values('"+proId+"','ani','07/10/2025','"+projectName+"','Created',0)");
	System.out.println(proId+" Project created");
	
		//Update project using API
		JSONObject jObj=new JSONObject();
		jObj.put("status", "Completed");
	Response res=given().spec(reqspecObj)
		.pathParam("id", proId)
		.body(jObj)
		.when()
		.patch(IEndPoint.updatePro);
		res.then().assertThat()
		.log().body();
		System.out.println("Project Status updated");
		
		//Delete using UI
		 WebDriver driver = new FirefoxDriver();
			driver.get(futils.getDataFromPropertyFile("BaseURI"));
			WebDriverUtility wUtils=new WebDriverUtility();
			wUtils.waitUntilPageGetLoads(driver);
			driver.manage().window().maximize();
			
			LoginPage loginpage=new LoginPage(driver);
			loginpage.login();
			
			HomePage homepage=new HomePage(driver);
			wUtils.waitUntilElementVisible(driver, homepage.getProjectPage());
	        homepage.getProjectPage().click();
	        
	    ProjectPage ppage=new ProjectPage(driver);
	    wUtils.waitUntilElementVisible(driver, ppage.getSearchTextField());
	    ppage.getSearchTextField().sendKeys(proId);
	    
	    WebElement deleteicon= driver.findElement(By.xpath("//td[.='"+proId+"']/../descendant::a[@class='delete']"));
	    deleteicon.click();
	    
	    wUtils.waitUntilElementVisible(driver, ppage.getDeleteButton());
	    ppage.getDeleteButton().click();
	    
	    Thread.sleep(1000);
	    WebElement popup= driver.findElement(By.xpath("//div[@role='alert' and text()='"+projectName+" Project Successfully Deleted ']"));
	    
	    System.out.println(popup.getText());
	    Assert.assertEquals(popup.getText(),""+projectName+" Project Successfully Deleted");
	    driver.close();
	}

}
