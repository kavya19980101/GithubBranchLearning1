package com.ninza.hrm.api.projecttest;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ninza.hrm.api.baseClass.BaseAPIClass;
import com.ninza.hrm.api.pojoclass.ProjecttPOJO;
import com.ninza.hrm.constants.endpoints.IEndPoint;
import com.ninza.hrm.generic.webdriverUtility.WebDriverUtility;
import com.ninza.hrm.objectRepository.HomePage;
import com.ninza.hrm.objectRepository.LoginPage;

import io.restassured.response.Response;


/*
 * Create Project in API
 * get it through DB
 * validate it created project in UI 
 */
public class CreateProjectViaAPI extends BaseAPIClass {
	
	
	
	ProjecttPOJO pObj;
	@Test
	public void addSingleProjectWithCreatedTest() throws IOException, SQLException {
     //Create project in API
		
	String projectName="Airtel"+jutils.getRandomNum();
	String userName="user"+jutils.getRandomNum();
	
	pObj=new ProjecttPOJO(userName, projectName, "Created", 0);
		Response resp=	given()
				.spec(reqspecObj)
			    .body(pObj)
			    .when()
		    	.post(IEndPoint.addPro);
		
			String projectid=resp.jsonPath().get("projectId");
			System.out.println("New Project created via API request with projectid "+projectid);
			System.out.println("-------------------------------------------------");
			
			//get the created project in DB Layer
			ResultSet data=dUtils.getSelectQuery("select * from project");
	
			while(data.next())
			{
				if(projectid.equals(data.getString(1)))
				{
				System.out.println("DataBaseDetails==>");
				System.out.println("ProjectID="+data.getString(1));
				System.out.println("CreatedBy="+data.getString(2));
				System.out.println("CreatedON="+data.getString(3));
				System.out.println("ProjectName="+data.getString(4));
				System.out.println("Status="+data.getString(5));
				System.out.println("TeamSize="+data.getInt(6));
				}
			}
			System.out.println("-------------------------------------------------");
			
			
			//Validate in Created Project in UI 
					
			   WebDriver driver = new FirefoxDriver();
				driver.get(futils.getDataFromPropertyFile("BaseURI"));
				WebDriverUtility wUtils=new WebDriverUtility();
				wUtils.waitUntilPageGetLoads(driver);
				driver.manage().window().maximize();
				
				LoginPage loginpage=new LoginPage(driver);
				loginpage.login();
				
				HomePage homepage=new HomePage(driver);
				wUtils.waitUntilElementVisible(driver, homepage.getProjectPage());
		        homepage.getProjectPage().click();
		        
		        WebElement createdProjectID= driver.findElement(By.xpath("//td[.='"+projectName+"']/preceding-sibling::td"));
		        wUtils.waitUntilElementVisible(driver, createdProjectID);
		        Assert.assertEquals(projectid, createdProjectID.getText());
		        System.out.println("Created project validated via UI");
		        driver.close();
	}
}
