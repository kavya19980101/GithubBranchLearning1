package com.ninza.hrm.api.projecttest;

import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ninza.hrm.api.baseClass.BaseAPIClass;
import com.ninza.hrm.api.genericutility.DataBaseUtility;
import com.ninza.hrm.api.genericutility.FileUtility;
import com.ninza.hrm.api.genericutility.JavaUtility;
import com.ninza.hrm.api.pojoclass.ProjecttPOJO;
import com.ninza.hrm.constants.endpoints.IEndPoint;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import java.io.IOException;
import java.sql.SQLException;

public class ProjectTest extends BaseAPIClass {
	
	ProjecttPOJO pObj;
	
	@Test
	public void addSingleProjectWithCreatedTest() throws IOException, SQLException {
     
		String BaseURI= futils.getDataFromPropertyFile("BaseURI");
		String expSucMsg="Successfully Added";
	String projectName="Airtel"+jutils.getRandomNum();
	String userName="user"+jutils.getRandomNum();
	
	pObj=new ProjecttPOJO(userName, projectName, "Created", 0);
		Response resp=	given()
				.spec(reqspecObj)
			    .body(pObj)
			    .when()
		    	.post(IEndPoint.addPro);
			
			     resp.then()
			.assertThat().statusCode(201)
			.assertThat().time(Matchers.lessThan(10000L))
			.log().all()
			.spec(resSpecObj);
			
			String actMsg=resp.jsonPath().get("msg");
			Assert.assertEquals(expSucMsg , actMsg);
			
			
			//Verify the projectName in DB Layer
			boolean flag= dUtils.selectQuery("select * from project", 4, projectName);
			Assert.assertTrue(flag, "Project in DB is not verified");
					
	}
	
	
	@Test(dependsOnMethods = "addSingleProjectWithCreatedTest")
	public void createDuplicateProjectTest()
	{
		given()
		.spec(reqspecObj)
		.body(pObj)
		.when()
		.post(IEndPoint.addPro)
		.then()
		.assertThat().statusCode(409)
		.log().all()
		.spec(resSpecObj);
	}

}