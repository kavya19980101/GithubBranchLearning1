package com.ninza.hrm.api.employeetest;

import java.awt.SplashScreen;
import java.sql.SQLException;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ninza.hrm.api.baseClass.BaseAPIClass;
import com.ninza.hrm.api.pojoclass.EmployeePOJO;
import com.ninza.hrm.api.pojoclass.ProjecttPOJO;
import com.ninza.hrm.constants.endpoints.IEndPoint;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class EmployeeTest extends BaseAPIClass {
	ProjecttPOJO pObj;
	@Test
	public void addEmployeeTest() throws SQLException
	{
		Random random=new Random();
		int ranNum=random.nextInt(5000);
		String projectName="Airtel"+ranNum;
		String userName="user"+ranNum;
		
		pObj=new ProjecttPOJO(userName,projectName,"Created",0);
		
		Response resp= given()
		.spec(reqspecObj)
		.body(pObj)
		.when()
		.post(IEndPoint.addPro);
		resp.then()
		.assertThat().statusCode(201)
		.log().all()
		.spec(resSpecObj);
		
		String proName= resp.jsonPath().get("projectName");
		System.out.println(proName);
	
		
		EmployeePOJO emp=new EmployeePOJO("Test Engineer", "kava1234@gmail.com",
				userName, 12, "9012345678", 
				proName, "ROLE_ADMIN", userName);  
		
		Response res= given()
		.spec(reqspecObj)
		.body(emp)
		.when()
		.post(IEndPoint.addEmp);
		res.then().log().all()
		.assertThat().statusCode(201)
		.spec(resSpecObj)
		.log().all();
		
		//Verify created employee in DB layer
		boolean flag= dUtils.selectQuery("select * from employee", 5, userName);
		Assert.assertTrue(flag, "Employee in DB is not verified");
		
		
	}
	
	@Test
	public void addEmployeeWithoutEmailTest() throws SQLException
	{
		Random random=new Random();
		int ranNum=random.nextInt(5000);
		String projectName="Airtel"+ranNum;
		String userName="user"+ranNum;
		
		pObj=new ProjecttPOJO(userName,projectName,"Created",0);
		
		Response resp= given()
		.spec(reqspecObj)
		.body(pObj)
		.when()
		.post(IEndPoint.addPro);
		resp.then()
		.assertThat().statusCode(201)
		.log().all()
		.spec(resSpecObj);
		
		String proName= resp.jsonPath().get("projectName");
		System.out.println(proName);
	
		
		EmployeePOJO emp=new EmployeePOJO("Test Engineer", "",
				userName, 12, "9012345678", 
				proName, "ROLE_ADMIN", userName);  
		
		Response res= given()
		.spec(reqspecObj)
		.body(emp)
		.when()
		.post(IEndPoint.addEmp);
		res.then().log().all()
		.assertThat().statusCode(201)
		.spec(resSpecObj)
		.log().all();
		
		//Verify created employee in DB layer
		boolean flag= dUtils.selectQuery("select * from employee", 5, userName);
		Assert.assertTrue(flag, "Employee in DB is not verified");
		
		
	}
	
}
