package com.ninza.hrm.generic.webdriverUtility;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverUtility {

	//Utility method for implicit wait
		public void waitUntilPageGetLoads(WebDriver driver)
		{
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(0));
		}
		
		//Utility method for explicit wait condition on visiblityOf(ele) method
		public void waitUntilElementVisible(WebDriver driver,WebElement ele) 
		{
			WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(40));
					wait.until(ExpectedConditions.visibilityOf(ele));
		}
		
		//Utility method for explicit wait condition on until url title contains
				public void waitUntilurl(WebDriver driver,String url) 
				{
					WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(40));
							wait.until(ExpectedConditions.urlContains(url));
				}
		
		//Utility method to perform mouse hovering actions
		public void getmouseHovering(WebDriver driver,WebElement ele)
		{
			Actions act=new Actions(driver);
			act.moveToElement(ele).perform();
		}
		
		//Utility method to perform drag and drop actions on mouse from source and destination
		public void getDragAndDrop(WebDriver driver,WebElement eleSource,WebElement eleDestination)
		{
			Actions act=new Actions(driver);
			act.dragAndDrop(eleSource,eleDestination).perform();
		}
		
		//Utility method to perform drag and drop actions on mouse from source to specific point
			public void getDragAndDrop(WebDriver driver,WebElement eleSource,int x,int y)
			{
				Actions act=new Actions(driver);
				act.dragAndDropBy(eleSource,x,y).perform();
			}
		
			//Utility method to perform click and hold action on mouse
		   public void getClickAndHold(WebDriver driver,WebElement ele)
		   {
			   Actions act=new Actions(driver);
			   act.clickAndHold(ele).perform();
		   }
		   
		   //Utility method to perform  double click action on mouse
		   public void getDoubleClick(WebDriver driver,WebElement ele)
		   {
			   Actions act=new Actions(driver);
			   act.doubleClick(ele).perform();
		   }
		   
		 //Utility method to perform right click action on mouse
		   public void getRightClick(WebDriver driver,WebElement ele)
		   {
			   Actions act=new Actions(driver);
			   act.contextClick(ele).perform();
		   }
		   
		   //Utility method to perform scroll to specific element
		   public void getScrollToElement(WebDriver driver,WebElement ele)
		   {
			   Actions act=new Actions(driver);
			   act.scrollToElement(ele).perform();
		   }
		   
		 //Utility method to perform scroll to specific point in web page
		   public void getScrollByAmount(WebDriver driver,int x,int y)
		   {
			   Actions act=new Actions(driver);
			   act.scrollByAmount(x,y).perform();
		   }
		   
		 //Utility method to pass data using Actions class 
		   public void getSendKeys(WebDriver driver,String str)
		   {
			   Actions act=new Actions(driver);
			   act.sendKeys(str).perform();
		   }
		   
		 //Utility method to key press on modifier key data using Actions class 
		   public void getKeyUp(WebDriver driver,String modifier)
		   {
			   Actions act=new Actions(driver);
			   if(modifier.equals("shift"))
			   {
			   act.keyDown(Keys.SHIFT);
			   }
			   else if (modifier.equals("control")) {
				 act.keyDown(Keys.CONTROL);
				}
				else if(modifier.equals("alter")){
					act.keyDown(Keys.ALT);
				}
			 }
		   
		 //Utility method to key release on modifier key data using Actions class 
		   public void getKeyDown(WebDriver driver,String modifier)
		   {
			   Actions act=new Actions(driver);
			   if(modifier.equals("shift"))
			   {
			   act.keyDown(Keys.SHIFT);
			   }
			   else if (modifier.equals("control")) {
				 act.keyDown(Keys.CONTROL);
				}
				else if(modifier.equals("alter")){
					act.keyDown(Keys.ALT);
				}
			 }
		   
		   public void switchToFrame(WebDriver driver,int index_value)
		   {
			   driver.switchTo().frame(index_value);
		   }
		   
		   public void switchToFrame(WebDriver driver,String name_id)
		   {
			   driver.switchTo().frame(name_id);
		   }
		   
		   public void switchToFrame(WebDriver driver,WebElement ele)
		   {
			   driver.switchTo().frame(ele);
		   }
		   
		   public void alertForAccept(WebDriver driver)
		   {
			   driver.switchTo().alert().accept();
		   }
		   
		   
		   public void alertForDismiss(WebDriver driver)
		   {
			   driver.switchTo().alert().dismiss();
		   }
		   
		   public void alertHandleBysendKeys(WebDriver driver,String value)
		   {
			   driver.switchTo().alert().sendKeys(value);
		   }
		   
		   public void getScreenShot(WebDriver driver,String path)
		   {
			 TakesScreenshot ts=(TakesScreenshot) driver;
			 File src= ts.getScreenshotAs(OutputType.FILE);
			 File dest=new File(path);
			 try {
				FileHandler.copy(src, dest);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
		   
		   public void getScreenShot(WebDriver driver, WebElement ele, String path)
		   {
			
			 File src= ele.getScreenshotAs(OutputType.FILE);
			 File dest=new File(path);
			 try {
				FileHandler.copy(src, dest);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
		  
		   public void selectDropDown(WebElement ele,int index)
		   {
			   Select s=new Select(ele);
			   s.selectByIndex(index);
		   }
		   
		   public void selectDropDown(WebElement ele,String visible_Text)
		   {
			   
			   Select s=new Select(ele);
			   s.selectByVisibleText(visible_Text);
		   }
		   
		   public void selectDropDown(String value,WebElement ele)
		   {
			   
			   Select s=new Select(ele);
			   s.selectByVisibleText(value);
		   }
		   
		   public void deselectDropDown(WebElement ele)
		   {
			   Select s=new Select(ele);
			   s.deselectAll();
		   }
		   
		   public void deselectDropdown(WebElement ele,int index)
		   {
			   Select s=new Select(ele);
			   s.deselectByIndex(index);
		   }
		   
		   public void deselectDropdown(WebElement ele,String visible_text)
		   {
			   Select s=new Select(ele);
			   s.deselectByVisibleText(visible_text);
		   }
		   
		   public void deselectDropdown(String value,WebElement ele)
		   {
			   Select s=new Select(ele);
			   s.deselectByValue(value);
		   }
		   
		   public boolean getisMultiple(WebElement ele)
		   {
			   Select s=new Select(ele);
			   return s.isMultiple();
		   }
		   
		   public void selectFirstSelectedOptionOnDropown(WebElement ele)
		   {
			   Select s=new Select(ele);
			   s.getFirstSelectedOption();
		   }
		   
		   public void selectAllSelectedOptionOnDropown(WebElement ele)
		   {
			   Select s=new Select(ele);
			   s.getAllSelectedOptions();
		   }
		   
		   public void getAllOptionsOfDropDown(WebElement ele)
		   {
			   Select s=new Select(ele);
			   s.getOptions();
		   }
		    
		   
		   
		  public void switchToWindowOnPartialUrl(WebDriver driver,String partial_url)
		  {
			  Set<String> allwindows=driver.getWindowHandles();
				Iterator<String> it= allwindows.iterator();
				while(it.hasNext())
				{
					String windowid= it.next();
					driver.switchTo().window(windowid);
					String current_Url=driver.getCurrentUrl();
					if(current_Url.contains(partial_url))
					{
						break;
					}
		        }
		  }	
		  
		  public void switchToWindowOnTitle(WebDriver driver,String title)
		  {
			  Set<String> allwindows=driver.getWindowHandles();
				Iterator<String> it= allwindows.iterator();
				while(it.hasNext())
				{
					String windowid= it.next();
					driver.switchTo().window(windowid);
					String current_title=driver.getTitle();
					if(current_title.contains(title))
					{
						break;
					}
		        }
		  }
		  
		  public void getClickOnDisableElement(WebDriver driver,WebElement ele)
		  {
			  JavascriptExecutor jse=(JavascriptExecutor)driver;
			  jse.executeScript("arguments[0].click();", ele);
			  
		  }
		   
	
}
