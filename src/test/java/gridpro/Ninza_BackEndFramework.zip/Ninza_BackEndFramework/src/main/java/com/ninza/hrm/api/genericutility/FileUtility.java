package com.ninza.hrm.api.genericutility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileUtility {

	public String getDataFromPropertyFile(String key) throws IOException
	{
		FileInputStream fis=new FileInputStream("./configAppData/CommonData.properties");
		Properties p=new Properties();
		p.load(fis);
		String property_file_data=p.getProperty(key);
		return property_file_data;
	}
	
}
