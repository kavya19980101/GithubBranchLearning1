package com.ninza.hrm.configuration;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.beust.jcommander.Parameter;
import com.ninza.hrm.api.genericutility.DataBaseUtility;
import com.ninza.hrm.api.genericutility.FileUtility;
import com.ninza.hrm.generic.webdriverUtility.WebDriverUtility;
import com.ninza.hrm.objectRepository.LoginPage;



public class BaseClass {
	DataBaseUtility dbutility=new DataBaseUtility();
    FileUtility putility=new FileUtility();
	WebDriverUtility wdu=new WebDriverUtility();
	public WebDriver driver;
	public static WebDriver sdriver;
//	@BeforeSuite
//	public void connectToDB()
//	{
//		dbutility.getConnectToDB(null, null, null);
//	}
//	@AfterSuite
//	public void disconnectWithDB()
//	{
//		dbutility.getDisconnectToDB();
//	}
	

//	@BeforeClass
//	public void lauchTheBrowser() throws IOException
//	{
//		
//			driver=new ChromeDriver();
//			driver.manage().window().maximize();
//		
//		sdriver=driver;
//	}
	
	@AfterMethod(alwaysRun = true)
	public void closeTheBrowser()
	{
		driver.quit();
	}
	
	@Parameters("Browser")
	@BeforeMethod(alwaysRun = true)
	public void enterUrl(@Optional("firefox")String Browser) throws IOException
	{
		String browser=Browser;
		if(browser.equals("firefox"))
		{
			driver=new FirefoxDriver();
		}
		else if (browser.equals("edge")) {
			driver=new EdgeDriver();
		}
		driver.manage().window().maximize();
	    sdriver=driver;
		wdu.waitUntilPageGetLoads(driver);
		driver.get(putility.getDataFromPropertyFile("BaseURI"));
		LoginPage loginpage=new LoginPage(driver);
		loginpage.login();
	}
	
	

}
