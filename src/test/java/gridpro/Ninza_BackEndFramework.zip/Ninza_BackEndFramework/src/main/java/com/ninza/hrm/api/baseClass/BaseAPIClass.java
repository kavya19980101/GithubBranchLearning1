package com.ninza.hrm.api.baseClass;

import java.io.IOException;
import java.nio.file.attribute.BasicFileAttributes;

import javax.swing.plaf.basic.BasicRootPaneUI;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.fasterxml.jackson.databind.introspect.TypeResolutionContext.Basic;
import com.ninza.hrm.api.genericutility.DataBaseUtility;
import com.ninza.hrm.api.genericutility.FileUtility;
import com.ninza.hrm.api.genericutility.JavaUtility;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class BaseAPIClass {

	
	public JavaUtility jutils=new JavaUtility();
	public FileUtility futils=new FileUtility();
	public DataBaseUtility dUtils=new DataBaseUtility();
	public static RequestSpecification reqspecObj;
	public static ResponseSpecification resSpecObj;
	@BeforeSuite
	public void configDB() throws IOException
	{
		dUtils.connecToDB();
		System.out.println("==============Connect to DB============");
		 RequestSpecBuilder reqbuilder=new RequestSpecBuilder();
		  reqbuilder.setContentType(ContentType.JSON);
		  //builder.setAuth(basic("username","password")); 
		  reqbuilder.addHeader("",""); 
		  reqbuilder.setBaseUri(futils.getDataFromPropertyFile("BaseURI"));
		  reqbuilder.addHeader("", ""); 
		  reqspecObj= reqbuilder.build();
		 
		  ResponseSpecBuilder resbuilder=new ResponseSpecBuilder();
		  resbuilder.expectContentType(ContentType.JSON);
		  resSpecObj=resbuilder.build();
		 
	}
	
	@AfterSuite
	public void closeDB()
	{
		dUtils.dbClose();
		System.out.println("============close the DB===========");
	}
	
}
 