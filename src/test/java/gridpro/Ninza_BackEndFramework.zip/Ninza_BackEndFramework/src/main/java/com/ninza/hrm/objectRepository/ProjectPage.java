package com.ninza.hrm.objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ProjectPage {

	@FindBy(xpath ="//input[@placeholder='Search by Project Id']")
	private WebElement searchProjectTextField;
	
	@FindBy(xpath ="//input[@value='Delete' and @type='button']")
	private WebElement deleteButton;
	
	@FindBy(xpath ="//span[.='Create Project']")
	private WebElement createProjectIcon;
	
	@FindBy(xpath ="//input[@name='projectName']")
	private WebElement proNametxtfield;
	
	@FindBy(xpath ="//input[@name='createdBy']")
	private WebElement createdBytxtfield;
	
	@FindBy(xpath ="(//select[@name='status'])[2]")
	private WebElement statusdropdown ;
	
	@FindBy(xpath ="//input[@type='submit']")
	private WebElement addButton ;
	
	
	public ProjectPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public WebElement getSearchTextField()
	{
		return searchProjectTextField;
	}
	
	public WebElement getDeleteButton()
	{
		return deleteButton;
	}
	
	public WebElement getCreateProjectIcon()
	{
		return createProjectIcon;
	}
	
	public void createProject(String proName,String CreatedBy, String status)
	{
		proNametxtfield.sendKeys(proName);
		createdBytxtfield.sendKeys(CreatedBy);
		Select s=new Select(statusdropdown);
		s.selectByVisibleText(status);
		addButton.click();
	}


	public WebElement getProNametxtfield() {
		return proNametxtfield;
	}


	public WebElement getCreatedBytxtfield() {
		return createdBytxtfield;
	}


	public WebElement getStatusdropdown() {
		return statusdropdown;
	}
	
	
	 
}
