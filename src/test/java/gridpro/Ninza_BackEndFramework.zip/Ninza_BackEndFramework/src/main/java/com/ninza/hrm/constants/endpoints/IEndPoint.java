package com.ninza.hrm.constants.endpoints;

public interface IEndPoint {

	public String addPro="/addProject";
	public String addEmp="/employees";
	public String getPro="/project/{projectId}";
	public String updatePro="/project/{id}";
}
