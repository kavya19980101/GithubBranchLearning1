package com.ninza.hrm.api.genericutility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.Driver;





public class DataBaseUtility {
	FileUtility futils=new FileUtility();
	
	Connection con;
	public void connecToDB(String url, String usn, String pwd)
	{
		Driver driver;
		try {
			driver=new Driver();
	DriverManager.registerDriver(driver);
	con=DriverManager.getConnection(url,usn, pwd);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void connecToDB()
	{
		Driver driver;
		try {
			driver=new Driver();
			DriverManager.registerDriver(driver);
			con=DriverManager.getConnection(futils.getDataFromPropertyFile("DBURL"),futils.getDataFromPropertyFile("DB_UserName"),futils.getDataFromPropertyFile("DB_Password"));
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public boolean selectQuery(String query, int columnIndex,String expectedData) throws SQLException
	{
		boolean flag=false;
		ResultSet result=null;
		
			Statement sta= con.createStatement();
			result=sta.executeQuery(query);
		while(result.next())
		{
			if(result.getString(columnIndex).equals(expectedData))
			{
				flag=true;
				break;
			}
		}
		if(flag)
		{
			System.out.println(expectedData+"====> data verified in data base table");
			return true;
		}
		else {
			System.out.println(expectedData+"====> data not verified in data base table");
			return false;
		}
		
	}
	
	public int executeNonSelectQuery(String query)
	{
		int result=0;
		try {
			Statement sta= con.createStatement();
			result=sta.executeUpdate(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	
	public void dbClose()
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ResultSet getSelectQuery(String query)
	{
	ResultSet data = null;
	try {
		Statement s = con.createStatement();
		data= s.executeQuery(query);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return data;

	}
	
}
